function X_baseframe = myjug(myrobot)
    % Reading excel data
    data=xlsread('jug.xlsx');
    disp(size(data))
    x=550 + 10*data(:,1)
    y=10*data(:,2)
    z=-0.5*ones(length(data),1);

    % Coordinate transformation
    X_workspace = [x'; y'; z'];
    disp(size(X_workspace))
    X_baseframe = zeros(3,length(data));
    for i = 1:length(data)
        X_baseframe(:, i) = FrameTransformation(X_workspace(:, i));
    end
end


    

