function X_baseframe = mysegment(myrobot)

    % Creating coordinates for a line using linspace
    % Constant x, z, moving along y-axis from -100 to 100
    y_i = linspace(-100, 100, 100);
    z_i = -0.9*ones(1,100); 
    x_i = 620*ones(1,100);
    X_workspace = [x_i; y_i; z_i];

    % Transform coordinates to the base frame
    X_baseframe = zeros(3,100);
    for i = 1:100
        X_baseframe(:, i) = FrameTransformation(X_workspace(:, i));
    end
end


    