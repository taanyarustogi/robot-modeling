function X_baseframe = myheart(myrobot)

    x = ones(1,100)
    y = ones(1,100)
    % create x and y according to heart function 
    for i = 1:100
        y(i) = (13*cos(2*pi*((i-1)/99))-5*cos(2*2*pi*((i-1)/99)) - 2*cos(3*2*pi*((i-1)/99)) - cos(4*2*pi*((i-1)/99)))*2;
        x(i) = 650 + (16*(sin(2*pi*((i-1)/99))^3))*2;
    end 
    
    %constant z
    z_i = -0.5*ones(1,100);
    X_workspace = [x; y; z_i];

    %frame transformation
    X_baseframe = zeros(3,100);
    for i = 1:100
        X_baseframe(:, i) = FrameTransformation(X_workspace(:, i));
    end
end


    