%% LAB 2
% Team Members: Hannah Lila (1008374251), Tanya Rustogi (1007828665),
% Caroline Wang (1008050485)

%% lab2 prelab
clear
clc

% Init robot
DH = [[0, 400, 25, pi/2]; [0, 0, 315, 0]; [0, 0, 35, pi/2]; [0, 365, 0, -pi/2]; [0, 0, 0, pi/2]; [0, 161.44, -296.33, 0]];
myrobot = mykuka(DH);
q = [pi/5 pi/3 -pi/4 pi/4 pi/3 pi/4];

F = forward_kuka(q, myrobot)
inverse_kuka(F, myrobot)

%% lab2 4.2
clearvars -except udpObj

% Calibrating the robot using our X1-3, Q1-3 values
delta = fminunc(@deltajoint, [0 0])
myrobot = mykuka_search(delta)

% Reset to home
setHome(0.04)

%% 4.2 Calibration

% X1 coordinate from pad
X1 = [784.05, 0.18, 20.93];

% Init transformation matrix with X1 as desired position
H = [[0 0 1 X1(1)];
     [0 -1 0 X1(2)];
     [1 0 0 X1(3)];
     [0 0 0 1]];

% Get joint angles
q = inverse_kuka(H, myrobot);

% Calibrated a6 and d6:
% delta =     -1.8504   -7.3505
% d6 =  161.44+delta(2) = 154.0895
% a6 = -296.33+delta(1) = -298.1804

setAngles(q, 0.04)
setHome(0.04)

%% 4.3 WS vs. Base Frame

%
p_workspace = [600; 100; 10];
p_baseframe = FrameTransformation(p_workspace);
H_target = [[0 0 1 p_baseframe(1)];
            [0 -1 0 p_baseframe(2)];
            [1 0 0 p_baseframe(3)];
            [0 0 0 1]];

q_target = inverse_kuka(H_target, myrobot);
setAngles(q_target, 0.04)

setHome(0.04);

%% 4.4 Drawing a Line

clearvars -except udpObj

% Init robot
delta = fminunc(@deltajoint, [0 0])
myrobot = mykuka_search(delta)

% Use segment function to extract target coordinates
X_baseframe = mysegment(myrobot)

% Use inverse_kuka to get desired joint angles and move robot accordingly
for i = 1:100
    H_target = [[0 0 1 X_baseframe(1,i)];
                [0 -1 0 X_baseframe(2,i)];
                [1 0 0 X_baseframe(3,i)];
                [0 0 0 1]];
     q = inverse_kuka(H_target, myrobot);
    setAngles(q, 0.04)
end

setHome(0.04)
%% Drawing a Circle
clearvars -except udpObj

% Init robot
delta = fminunc(@deltajoint, [0 0])
myrobot = mykuka_search(delta)

% Use circle function to extract target coordinates
X_baseframe = mycircle(myrobot)

% Use inverse_kuka to get desired joint angles and move robot accordingly
for i = 1:100
    H_target = [[0 0 1 X_baseframe(1,i)];
                [0 -1 0 X_baseframe(2,i)];
                [1 0 0 X_baseframe(3,i)];
                [0 0 0 1]];
    q = inverse_kuka(H_target, myrobot);
    setAngles(q, 0.04)
end
setHome(0.04)

%% Drawing a Jug

clearvars -except udpObj

% Init robot
delta = fminunc(@deltajoint, [0 0])
myrobot = mykuka_search(delta)

% Use jug function to extract target coordinates
X_baseframe = myjug(myrobot)

% Use inverse_kuka to get desired joint angles and move robot accordingly
for i = 1:size(X_baseframe, 2)
    H_target = [[0 0 1 X_baseframe(1,i)];
                [0 -1 0 X_baseframe(2,i)];
                [1 0 0 X_baseframe(3,i)];
                [0 0 0 1]];
    q = inverse_kuka(H_target, myrobot);
    setAngles(q, 0.04)
end
setHome(0.04)

%% Drawing a Heart

clearvars -except udpObj

% Init robot
delta = fminunc(@deltajoint, [0 0])
myrobot = mykuka_search(delta)

% Use heart function to extract target coordinates
X_baseframe = myheart(myrobot)

% Use inverse_kuka to get desired joint angles and move robot accordingly
for i = 1:size(X_baseframe, 2)
    H_target = [[0 0 1 X_baseframe(1,i)];
                [0 -1 0 X_baseframe(2,i)];
                [1 0 0 X_baseframe(3,i)];
                [0 0 0 1]];
    q = inverse_kuka(H_target, myrobot);
    setAngles(q, 0.04)
end
setHome(0.04)

