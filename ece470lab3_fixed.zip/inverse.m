function q = inverse(H, myrobot)

    % Extracting end-effector positions from our matrix
    pc = H(1:3,4) - H(1:3,3)*myrobot.d(1,6)

    %y_c = H(2,4);
    %x_c = H(1,4);
    y_c = pc(2);
    x_c = pc(1);
    z_c = pc(3);
    % Extracting information from DH table
    d_1 = myrobot.d(1, 1);
    d_2 = myrobot.d(1,2);
    d_4 = myrobot.d(1,4);

    a_2 = myrobot.a(1,2);

    D = (x_c^2 + y_c^2 - d_2^2 + (z_c - d_1)^2 - (a_2)^2 - (d_4)^2) / (2 * a_2 * d_4);

    % Calculate the inverse kinematics for the robot's joints (q1, q2, q3)
    q(1,1) = atan2(y_c, x_c) - atan2(-d_2, real(sqrt(x_c^2 + y_c^2 - d_2^2)));
    q(1,3) = atan2(D, real(sqrt(1 - D^2)));
    q(1,2) = atan2(z_c - d_1, real(sqrt(x_c^2 + y_c^2 - d_2^2))) - atan2(-d_4 * cos(q(1,3)), a_2 + d_4 * sin(q(1,3)));
    
    % Calculate the inverse kinematics for the robot's joints (q4, q5, q6)
    H3_0 = eye(4);

    % Compute H3_0 (multiplying H3_2, H2_1, H1_0)
    for i = 1:3
        alpha = myrobot.alpha(i);
        a = myrobot.a(i)
        theta = q(i);
        d = myrobot.d(i);
        temp = [cos(theta), -sin(theta)*cos(alpha), sin(theta)*sin(alpha), a*cos(theta);
                 sin(theta), cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta);
                 0, sin(alpha), cos(alpha), d;
                 0, 0, 0, 1];
        H3_0 = H3_0 * temp;
    end

    % Isolating H3_6 (multiplying H6_0, H3_0)
    r = transpose(H3_0(1:3, 1:3)) * H(1:3, 1:3);

    % Extracting joint information (q4, q5, q6)
    q(1,4) = atan2(r(2,3), r(1,3));    
    q(1,5) = atan2(real(sqrt(1-(r(3,3))^2)), r(3,3));
    q(1,6) = atan2(r(3,2), -r(3,1));
end