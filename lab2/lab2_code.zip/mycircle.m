function X_baseframe = mycircle(myrobot)

    x = ones(1,100)
    y = ones(1,100)

    % Creating x and y coordinates within a circle using sin and cos
    for i = 1:100
        y(i) = 50*sin(2*pi*((i-1)/100));
        x(i) = 620 + 50*cos(2*pi*((i-1)/100));
    end 

    z_i = -0.5*ones(1,100); % Constant z
    X_workspace = [x; y; z_i];

    % Transform coordinates to the base frame
    X_baseframe = zeros(3,100);
    for i = 1:100
        X_baseframe(:, i) = FrameTransformation(X_workspace(:, i));
    end
end


    