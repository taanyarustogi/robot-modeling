%% LAB 1 
% Team Members: Hannah Lila (1008374251), Tanya Rustogi (1007828665),
% Caroline Wang (1008050485)

%% 4.1 Robot Structure

DH = [0, 76, 0, pi/2; 0, -23.65, 43.23, 0; 0, 0, 0, pi/2; 0, 43.18, 0, -pi/2; 0, 0, 0, pi/2; 0, 20, 0, 0]
myrobot = mypuma560(DH)

%% 4.2 Plot Joint Trajectory
clear 

% Creating the 200x6 matrix q
theta1 = linspace(0, pi, 200);
theta2 = linspace(0, pi/2, 200);
theta3 = linspace(0, pi, 200);
theta4 = linspace(pi/4, 3*pi/4, 200);
theta5 = linspace(-pi/3, pi/3, 200);
theta6 = linspace(0, 2*pi, 200);

q = [transpose(theta1), transpose(theta2), transpose(theta3), transpose(theta4), transpose(theta5), transpose(theta6)];

% Init robot using mypuma560 function
DH = [0, 76, 0, pi/2; 0, -23.65, 43.23, 0; 0, 0, 0, pi/2; 0, 43.18, 0, -pi/2; 0, 0, 0, pi/2; 0, 20, 0, 0]
myrobot = mypuma560(DH)

% Plot
clf
plot(myrobot,q)
%% 4.3 Forward Kinematics
clear
clc

% Init robot using mypuma560 function
DH = [0, 76, 0, pi/2; 0, -23.65, 43.23, 0; 0, 0, 0, pi/2; 0, 43.18, 0, -pi/2; 0, 0, 0, pi/2; 0, 20, 0, 0]
myrobot = mypuma560(DH)

% Creating the 200x6 matrix q
theta1 = linspace(0, pi, 200);
theta2 = linspace(0, pi/2, 200);
theta3 = linspace(0, pi, 200);
theta4 = linspace(pi/4, 3*pi/4, 200);
theta5 = linspace(-pi/3, pi/3, 200);
theta6 = linspace(0, 2*pi, 200);

q = [transpose(theta1), transpose(theta2), transpose(theta3), transpose(theta4), transpose(theta5), transpose(theta6)];


% Calling forward function to find end effector coordinates and store in o
o = zeros(200,3);
for i = 1:200
    H = forward(q(i,:), myrobot);
    o(i, :) = H(1:3,4);
end

clf
figure;
plot3(o(:,1), o(:,2), o(:,3), 'r')
hold on

plot(myrobot,q)
%% 4.4 Inverse Kinematics
clear
clc

% Init robot using mypuma560 function
DH = [0, 76, 0, pi/2; 0, -23.65, 43.23, 0; 0, 0, 0, pi/2; 0, 43.18, 0, -pi/2; 0, 0, 0, pi/2; 0, 20, 0, 0]
myrobot = mypuma560(DH)

% Testing the inverse function
H_4 = [cos(pi/4) -sin(pi/4) 0 20; sin(pi/4) cos(pi/4) 0 23; 0 0 1 15; 0 0 0 1]
q_4 = inverse(H_4, myrobot)

% 100 x 3 matrix
x = linspace(10,30,100);
y = linspace(23,30,100);
z = linspace(15,100,100);

d = [transpose(x), transpose(y), transpose(z)];

% Rotation matrix about z by pi/4
R = [cos(pi/4), -sin(pi/4), 0; sin(pi/4), cos(pi/4), 0; 0, 0, 1];

% Store the joint angles for the trajectory
q = zeros(100, 6);
for i = 1:100
    H_temp = eye(4);
    H_temp(1:3, 1:3) = R;
    H_temp(1:3, 4) = transpose(d(i, :));
    q(i, :) = inverse(H_temp, myrobot);
end

clf
plot3(d(:,1), d(:,2), d(:,3), 'r')
hold on

plot(myrobot,q)